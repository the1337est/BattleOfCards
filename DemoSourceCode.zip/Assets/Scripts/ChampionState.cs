﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ChampionState
{
    None,
    Idle,
    Attacking,
    TakingHit,
    Dead

}
