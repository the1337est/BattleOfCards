﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct GridPos
{

    public int Side;
    public int X;
    public int Y;

}
